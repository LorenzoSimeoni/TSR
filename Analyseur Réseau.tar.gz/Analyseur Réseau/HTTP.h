

void PrintHeaderTCP(int EtherSize, int IpSize,int TCPSize,const u_char *packet,int Verbosite,const struct pcap_pkthdr *header);